default_app_config = 'wesgarlock.blog.apps.BlogConfig'
