default_app_config = 'wesgarlock.front.apps.FrontConfig'
